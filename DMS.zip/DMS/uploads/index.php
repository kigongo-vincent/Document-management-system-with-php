<?php
header('Location: ../adminlogin.php');