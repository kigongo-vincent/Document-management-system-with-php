<?php
$c = mysqli_connect('localhost', 'root', '', 'moict');
